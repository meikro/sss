const model = require('./model.js')

model.sync()

console.log('init db ok.')
