var config = {
  database: 'douyin',
  dialect: 'mysql',
  username: 'root',
  password: '123456',
  host: 'localhost',
  port: 3306
}

module.exports = config
