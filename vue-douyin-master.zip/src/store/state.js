const state = {
  isLogged: false,
  loginInfo: {},
  fanUnreadNum: 0,
  byLikeUnreadNum: 0,
  byCommentUnreadNum: 0,
  atNum: 0,
  followedNewsNum: 0,
  allPrivateLetter: [],
  popularVideo: [],
  playList: []
}
export default state
