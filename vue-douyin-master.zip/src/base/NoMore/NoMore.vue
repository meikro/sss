<template>
  <div class="no-more">
    暂时没有更多了
  </div>
</template>

<script>
export default {

}
</script>

<style scoped lang='stylus'>
@import '~@/common/stylus/variable'
.no-more
  text-align center
  font-size $font-size-small
  color $color-time
  padding-bottom 12px
</style>
