export const baseURL = 'http://127.0.0.1:3000' // 本地
// export const baseURL = 'http://192.168.1.100:3000' // 寝室
// export const baseURL = 'http://192.168.200.14:3000' // 公司
// export const baseURL = 'http://www.zhoubaba.club' // 服务器
